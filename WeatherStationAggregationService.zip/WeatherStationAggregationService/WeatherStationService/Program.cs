using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using WeatherStationService;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.ConfigureKestrel(o => o.Limits.MaxRequestBodySize = null);
var app = builder.Build();

var apiKey = app.Configuration["ApiKey"];
if (string.IsNullOrWhiteSpace(apiKey))
{
    throw new Exception("ApiKey is not configured.");
}

app.Use(async (context, next) =>
{
    var sent = context.Request.Headers["X-Api-Key"].ToString();

    if (!CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(sent), Encoding.UTF8.GetBytes(apiKey)))
    {
        context.Response.StatusCode = 401;
        await context.Response.WriteAsync("Missing or invalid API key.");
        return;
    }

    await next();
});

var readOptions = new JsonSerializerOptions(JsonSerializerDefaults.Web);
var writeOptions = new JsonSerializerOptions { Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping };

app.MapPost("/api/weather/stationaggregate", async (HttpContext context) =>
{
    var stations = new Dictionary<string, StationTemperature>(
        StringComparer.OrdinalIgnoreCase);

    using var reader = new StreamReader(context.Request.Body);
    int lineNumber = 0;
    string? line;

    while ((line = await reader.ReadLineAsync()) != null)
    {
        lineNumber++;

        if (string.IsNullOrWhiteSpace(line))
            continue;

        try
        {
            var measurement = JsonSerializer.Deserialize<Measurement>(line, readOptions);

            if (!IsValid(measurement))
                return Results.BadRequest($"Invalid data at line {lineNumber}");

            var name = measurement!.StationName!;

            if (!stations.ContainsKey(name))
                stations.Add(name, new StationTemperature());

            stations[name].AddTemperature(measurement.Temperature!.Value);
        }
        catch (JsonException)
        {
            return Results.BadRequest($"Invalid JSON at line {lineNumber}");
        }
    }

    context.Response.ContentType = "application/x-ndjson";

    foreach (var item in stations.OrderBy(x => ToCamelCase(x.Key)))
    {
        var t = item.Value;
        var name = JsonSerializer.Serialize(ToCamelCase(item.Key), writeOptions);

        await context.Response.WriteAsync(
            $"{{\"stationName\":{name},\"min\":{Format(t.Min)},\"mean\":{Format(t.Mean)},\"max\":{Format(t.Max)}}}\n");
    }

    return Results.Empty;
});

app.Run();

static bool IsValid(Measurement? m)
{
    if (m?.StationName == null || m.Temperature == null)
        return false;

    var temp = m.Temperature.Value;

    return Encoding.UTF8.GetByteCount(m.StationName) <= 100
        && temp >= -99.9 && temp <= 99.9
        && Math.Round(temp, 1) == temp;
}

static string ToCamelCase(string name)
{
    return string.Join(" ", name.Split(' ')
        .Select(word => word.Length > 0
            ? char.ToUpper(word[0]) + word.Substring(1).ToLower()
            : word));
}

static string Format(double value)
{
    return value.ToString("F1", CultureInfo.InvariantCulture);
}

record Measurement(string? StationName, double? Temperature);
