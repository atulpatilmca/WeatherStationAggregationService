﻿namespace WeatherStationService
{
    public class StationTemperature
    {
        public double totalTemp { get; set; }
        public double Min { get; set; }
        public double Max { get; set; }
        public int Count { get; set; }
        public double Mean => totalTemp / Count;

        public void AddTemperature(double temperature)
        {
            if (Count == 0)
            {
                Min = temperature;
                Max = temperature;
            }
            else
            {
                if (temperature < Min)
                    Min = temperature;

                if (temperature > Max)
                    Max = temperature;
            }

            totalTemp += temperature;
            Count++;
        }

    }
}

