﻿using System.Globalization;
using System.Text.Json;

var settings = JsonDocument.Parse(
    File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "appsettings.json"))).RootElement;

var apiKey = settings.GetProperty("ApiKey").GetString();
var baseUrl = settings.GetProperty("ServiceUrl").GetString();

Console.Write("How many measurements? [100]: ");
var answer = args.Length > 0 ? args[0] : Console.ReadLine();

if (string.IsNullOrWhiteSpace(answer))
    answer = "100";

var filePath = Path.Combine(Path.GetTempPath(), "measurements.jsonl");

if (answer.Trim().ToLower() == "m")
{
    var lines = new List<string>();
    string? line;

    Console.WriteLine("Enter measurements. Press Enter on an empty line to finish:");

    while (!string.IsNullOrWhiteSpace(line = Console.ReadLine()))
        lines.Add(line);

    File.WriteAllLines(filePath, lines);
}
else if (int.TryParse(answer, out int count) && count > 0)
{
    var stations = new[] { "Hamburg", "Bulawayo", "Palembang", "New York", "St. John's", "Rio de Janeiro", "Dublin", "Tokyo" };
    var random = new Random();

    using var writer = new StreamWriter(filePath);

    for (int i = 0; i < count; i++)
    {
        var name = stations[random.Next(stations.Length)];
        if (random.Next(2) == 0) name = name.ToUpper();

        var temp = random.Next(-500, 501) / 10.0;

        writer.WriteLine(
            $"{{\"stationName\":\"{name}\",\"temperature\":{temp.ToString("0.0", CultureInfo.InvariantCulture)}}}");
    }
}
else
{
    Console.WriteLine("Enter a valid number greater than zero.");
    return;
}

using var http = new HttpClient { BaseAddress = new Uri(baseUrl!), Timeout = TimeSpan.FromMinutes(30) };
http.DefaultRequestHeaders.Add("X-Api-Key", apiKey);

try
{
    using var file = File.OpenRead(filePath);
    var response = await http.PostAsync("/api/weather/stationaggregate", new StreamContent(file));
    Console.Write(await response.Content.ReadAsStringAsync());
}
catch (HttpRequestException ex)
{
    Console.WriteLine($"Connection failed: {ex.Message}");
}